// Bundled sticker packs (Phase 1.6). All artwork is ORIGINAL, drawn with
// basic SVG shapes for this app — no third-party sticker art. Assets live
// under public/stickers/ and ship with the build.

export interface StickerDef {
  id: string;
  name: string;
  /** Asset URL (public/stickers/...). */
  url: string;
}

export interface StickerPack {
  id: string;
  name: string;
  nameBn: string;
  stickers: StickerDef[];
}

const base = `${import.meta.env.BASE_URL || '/'}stickers/`;

const pack = (
  id: string,
  name: string,
  nameBn: string,
  dir: string,
  items: Array<[string, string]>
): StickerPack => ({
  id,
  name,
  nameBn,
  stickers: items.map(([sid, sname]) => ({
    id: sid,
    name: sname,
    url: `${base}${dir}/${sid}.svg`,
  })),
});

export const STICKER_PACKS: StickerPack[] = [
  pack('chitthi-faces', 'Faces', 'মুখ', 'faces', [
    ['smile', 'Smile'],
    ['laugh', 'Laugh'],
    ['love', 'Love'],
    ['wink', 'Wink'],
    ['think', 'Thinking'],
    ['sleepy', 'Sleepy'],
    ['cool', 'Cool'],
    ['party', 'Party'],
  ]),
  pack('chitthi-pets', 'Pets & Things', 'পোষা ও অন্যান্য', 'pets', [
    ['cat', 'Cat'],
    ['dog', 'Dog'],
    ['bunny', 'Bunny'],
    ['bird', 'Bird'],
    ['star', 'Star'],
    ['heart', 'Heart'],
    ['rocket', 'Rocket'],
    ['flower', 'Flower'],
  ]),
];

export function findSticker(packId: string, stickerId: string): StickerDef | undefined {
  return STICKER_PACKS.find((p) => p.id === packId)?.stickers.find((s) => s.id === stickerId);
}
