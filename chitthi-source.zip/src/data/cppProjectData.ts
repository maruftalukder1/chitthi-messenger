export interface CppFile {
  name: string;
  language: string;
  description: string;
  content: string;
}

export const CPP_PROJECT_FILES: CppFile[] = [
  {
    name: 'protocol.hpp',
    language: 'cpp',
    description: 'বাইনারি প্যাকেট প্রোটোকল ও নেটওয়ার্ক ফ্রেম স্ট্রাকচার (Network Packet Protocol)',
    content: `/**
 * @file protocol.hpp
 * @brief Binary Packet Protocol for C++ Multi-User Multimedia Chat
 * @author Chitthi Engineering Team
 * 
 * Supports text, images, video chunks, and voice audio streams.
 */

#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <cstring>

namespace Chitthi {

// 4-byte Magic Number to validate packets: 'P' 'C' 'H' 'T'
constexpr uint32_t MAGIC_HEADER = 0x50434854;

enum class PacketType : uint16_t {
    AUTH_REQUEST    = 1001,
    AUTH_RESPONSE   = 1002,
    MSG_TEXT        = 2001,
    MSG_IMAGE       = 2002,
    MSG_VIDEO_CHUNK = 2003,
    MSG_AUDIO_VOICE = 2004,
    USER_PRESENCE   = 3001,
    TYPING_NOTIFY   = 3002,
    ERROR_NOTIFY    = 4001,
    PING            = 5001,
    PONG            = 5002
};

#pragma pack(push, 1)
struct PacketHeader {
    uint32_t magic;          // Must equal MAGIC_HEADER
    uint16_t packet_type;    // Cast to PacketType
    uint32_t payload_len;    // Length of the following binary payload
    uint32_t sender_id;      // Unique client identifier
    uint32_t target_room;    // 0 = General, >0 = Channel ID or User DM ID
    uint64_t timestamp;      // Milliseconds epoch timestamp
};
#pragma pack(pop)

// Helper class to serialize and deserialize packets over raw TCP sockets
class PacketSerializer {
public:
    static std::vector<uint8_t> createPacket(
        PacketType type,
        uint32_t senderId,
        uint32_t targetRoom,
        uint64_t timestamp,
        const uint8_t* payload,
        uint32_t payloadLength
    ) {
        PacketHeader header{};
        header.magic = MAGIC_HEADER;
        header.packet_type = static_cast<uint16_t>(type);
        header.payload_len = payloadLength;
        header.sender_id = senderId;
        header.target_room = targetRoom;
        header.timestamp = timestamp;

        std::vector<uint8_t> buffer(sizeof(PacketHeader) + payloadLength);
        std::memcpy(buffer.data(), &header, sizeof(PacketHeader));
        if (payloadLength > 0 && payload != nullptr) {
            std::memcpy(buffer.data() + sizeof(PacketHeader), payload, payloadLength);
        }
        return buffer;
    }
};

} // namespace Chitthi
`
  },
  {
    name: 'server.cpp',
    language: 'cpp',
    description: 'মাল্টি-থ্রেডেড C++ সকেট সার্ভার (Multi-threaded Async TCP Socket Server)',
    content: `/**
 * @file server.cpp
 * @brief High-Performance Multi-Client Multimedia Chat Server in C++20
 * 
 * Features:
 * - POSIX Sockets with Non-Blocking I/O & Thread Pooling
 * - Multi-Room and Direct Messaging (1-to-1 DMs)
 * - Binary frame routing for Images, Videos, Voice, and Text
 * - Thread-safe synchronization via std::mutex and std::shared_mutex
 */

#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <mutex>
#include <shared_mutex>
#include <unordered_map>
#include <memory>
#include <chrono>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include "protocol.hpp"

using namespace Chitthi;

struct ConnectedClient {
    int socket_fd;
    uint32_t user_id;
    std::string username;
    uint32_t current_room_id;
    sockaddr_in address;
    bool authenticated{false};
};

class ChatServer {
private:
    int server_fd{-1};
    int port{8080};
    bool is_running{false};

    // Thread-safe client registry
    std::unordered_map<int, std::shared_ptr<ConnectedClient>> clients;
    mutable std::shared_mutex clients_mutex;

public:
    explicit ChatServer(int listen_port) : port(listen_port) {}

    ~ChatServer() {
        stop();
    }

    bool start() {
        server_fd = socket(AF_INET, SOCK_STREAM, 0);
        if (server_fd < 0) {
            std::cerr << "[ERROR] Failed to create TCP socket!\\n";
            return false;
        }

        int opt = 1;
        setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

        sockaddr_in server_addr{};
        server_addr.sin_family = AF_INET;
        server_addr.sin_addr.s_addr = INADDR_ANY;
        server_addr.sin_port = htons(port);

        if (bind(server_fd, reinterpret_cast<sockaddr*>(&server_addr), sizeof(server_addr)) < 0) {
            std::cerr << "[ERROR] Socket bind failed on port " << port << "\\n";
            close(server_fd);
            return false;
        }

        if (listen(server_fd, 50) < 0) {
            std::cerr << "[ERROR] Listen failed!\\n";
            close(server_fd);
            return false;
        }

        is_running = true;
        std::cout << "================================================\\n";
        std::cout << "   Chitthi C++ Real-Time Server Online!       \\n";
        std::cout << "   Listening on port: " << port << "                     \\n";
        std::cout << "   Ready for Text, Image, Video, & Audio Frames \\n";
        std::cout << "================================================\\n";

        // Accept loop
        while (is_running) {
            sockaddr_in client_addr{};
            socklen_t client_len = sizeof(client_addr);
            int client_fd = accept(server_fd, reinterpret_cast<sockaddr*>(&client_addr), &client_len);

            if (client_fd < 0) {
                if (!is_running) break;
                continue;
            }

            char ip_str[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &(client_addr.sin_addr), ip_str, INET_ADDRSTRLEN);
            std::cout << "[INFO] New connection accepted from: " << ip_str << ":" << ntohs(client_addr.sin_port) << "\\n";

            auto client = std::make_shared<ConnectedClient>();
            client->socket_fd = client_fd;
            client->address = client_addr;
            client->current_room_id = 0; // default room

            {
                std::unique_lock lock(clients_mutex);
                clients[client_fd] = client;
            }

            // Launch worker thread for client session
            std::thread(&ChatServer::handleClientSession, this, client).detach();
        }

        return true;
    }

    void stop() {
        is_running = false;
        if (server_fd >= 0) {
            close(server_fd);
            server_fd = -1;
        }
        std::unique_lock lock(clients_mutex);
        for (auto& [fd, client] : clients) {
            close(fd);
        }
        clients.clear();
        std::cout << "[INFO] Chitthi server terminated cleanly.\\n";
    }

private:
    void handleClientSession(std::shared_ptr<ConnectedClient> client) {
        int fd = client->socket_fd;
        std::vector<uint8_t> rx_buffer(4096);

        while (is_running) {
            PacketHeader header{};
            ssize_t bytes_read = recv(fd, &header, sizeof(PacketHeader), MSG_WAITALL);
            if (bytes_read <= 0) {
                // Client disconnected
                break;
            }

            // Validate Magic Header
            if (header.magic != MAGIC_HEADER) {
                std::cerr << "[WARN] Invalid packet header magic from FD " << fd << "\\n";
                break;
            }

            // Read the binary payload (Text, Image bytes, Video chunk, or PCM audio)
            std::vector<uint8_t> payload(header.payload_len);
            if (header.payload_len > 0) {
                ssize_t total_payload = 0;
                while (total_payload < static_cast<ssize_t>(header.payload_len)) {
                    ssize_t n = recv(fd, payload.data() + total_payload, 
                                     header.payload_len - total_payload, 0);
                    if (n <= 0) break;
                    total_payload += n;
                }
            }

            processPacket(client, header, payload);
        }

        // Cleanup on disconnect
        std::cout << "[INFO] Client " << client->username << " (FD: " << fd << ") disconnected.\\n";
        {
            std::unique_lock lock(clients_mutex);
            clients.erase(fd);
        }
        close(fd);
    }

    void processPacket(std::shared_ptr<ConnectedClient> sender, const PacketHeader& header, const std::vector<uint8_t>& payload) {
        auto type = static_cast<PacketType>(header.packet_type);

        switch (type) {
            case PacketType::AUTH_REQUEST: {
                std::string username(reinterpret_cast<const char*>(payload.data()), payload.size());
                sender->username = username;
                sender->user_id = static_cast<uint32_t>(sender->socket_fd * 100);
                sender->authenticated = true;
                std::cout << "[AUTH] User authenticated: " << sender->username << " (ID: " << sender->user_id << ")\\n";
                break;
            }

            case PacketType::MSG_TEXT:
            case PacketType::MSG_IMAGE:
            case PacketType::MSG_VIDEO_CHUNK:
            case PacketType::MSG_AUDIO_VOICE: {
                std::string typeName = (type == PacketType::MSG_TEXT) ? "TEXT" :
                                       (type == PacketType::MSG_IMAGE) ? "IMAGE" :
                                       (type == PacketType::MSG_VIDEO_CHUNK) ? "VIDEO" : "VOICE_AUDIO";

                std::cout << "[ROUTE] Relaying " << typeName << " payload (" << payload.size() 
                          << " bytes) from " << sender->username << " to Room " << header.target_room << "\\n";

                // Re-broadcast binary packet to relevant clients in the same room
                broadcastToRoom(sender, header, payload);
                break;
            }

            default:
                break;
        }
    }

    void broadcastToRoom(std::shared_ptr<ConnectedClient> sender, const PacketHeader& header, const std::vector<uint8_t>& payload) {
        auto packet = PacketSerializer::createPacket(
            static_cast<PacketType>(header.packet_type),
            sender->user_id,
            header.target_room,
            header.timestamp,
            payload.data(),
            payload.size()
        );

        std::shared_lock lock(clients_mutex);
        for (const auto& [fd, client] : clients) {
            // Forward to peers in the target room (excluding sender)
            if (fd != sender->socket_fd && client->authenticated) {
                send(fd, packet.data(), packet.size(), 0);
            }
        }
    }
};

int main(int argc, char* argv[]) {
    int port = 8080;
    if (argc > 1) {
        port = std::stoi(argv[1]);
    }
    ChatServer server(port);
    server.start();
    return 0;
}
`
  },
  {
    name: 'client.cpp',
    language: 'cpp',
    description: 'C++ ক্লায়েন্ট ও মিডিয়া সেন্ডার (C++ Multi-threaded Client & Media Sender)',
    content: `/**
 * @file client.cpp
 * @brief Full C++ Multi-User Chat Client with Image/Video/Audio Streaming
 * 
 * Features:
 * - Asynchronous background receiver thread
 * - Interactive command-line interface (/image, /video, /audio, /quit)
 * - Raw binary media file chunking & transmission
 */

#include <iostream>
#include <string>
#include <vector>
#include <thread>
#include <fstream>
#include <chrono>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include "protocol.hpp"

using namespace Chitthi;

class ChatClient {
private:
    int socket_fd{-1};
    std::string username;
    bool is_running{false};
    std::thread rx_thread;

public:
    ChatClient(const std::string& name) : username(name) {}

    ~ChatClient() {
        disconnect();
    }

    bool connectToServer(const std::string& host, int port) {
        socket_fd = socket(AF_INET, SOCK_STREAM, 0);
        if (socket_fd < 0) {
            std::cerr << "[ERROR] Cannot create TCP socket\\n";
            return false;
        }

        sockaddr_in server_addr{};
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(port);
        inet_pton(AF_INET, host.c_str(), &server_addr.sin_addr);

        if (connect(socket_fd, reinterpret_cast<sockaddr*>(&server_addr), sizeof(server_addr)) < 0) {
            std::cerr << "[ERROR] Failed to connect to server at " << host << ":" << port << "\\n";
            close(socket_fd);
            return false;
        }

        is_running = true;
        std::cout << "[CONNECTED] Connected successfully to Chitthi Server!\\n";

        // Send Authentication Packet
        sendAuth();

        // Start background receiver
        rx_thread = std::thread(&ChatClient::receiveLoop, this);
        return true;
    }

    void sendTextMessage(const std::string& text, uint32_t roomId = 0) {
        auto now = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

        auto packet = PacketSerializer::createPacket(
            PacketType::MSG_TEXT,
            0,
            roomId,
            now,
            reinterpret_cast<const uint8_t*>(text.data()),
            text.size()
        );
        send(socket_fd, packet.data(), packet.size(), 0);
    }

    void sendMediaFile(const std::string& filepath, PacketType mediaType, uint32_t roomId = 0) {
        std::ifstream file(filepath, std::ios::binary | std::ios::ate);
        if (!file.is_open()) {
            std::cerr << "[ERROR] Cannot open media file: " << filepath << "\\n";
            return;
        }

        std::streamsize size = file.tellg();
        file.seekg(0, std::ios::beg);

        std::vector<uint8_t> buffer(size);
        if (file.read(reinterpret_cast<char*>(buffer.data()), size)) {
            auto now = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();

            auto packet = PacketSerializer::createPacket(
                mediaType,
                0,
                roomId,
                now,
                buffer.data(),
                buffer.size()
            );

            send(socket_fd, packet.data(), packet.size(), 0);
            std::cout << "[SUCCESS] Sent media payload (" << size << " bytes) to room " << roomId << "\\n";
        }
    }

    void runConsole() {
        std::cout << "\\n========================================\\n";
        std::cout << "Commands:\\n";
        std::cout << "  /image <path>  - Send an image file\\n";
        std::cout << "  /video <path>  - Send a video clip\\n";
        std::cout << "  /audio <path>  - Send voice/audio note\\n";
        std::cout << "  /quit          - Exit application\\n";
        std::cout << "========================================\\n\\n";

        std::string input;
        while (is_running && std::getline(std::cin, input)) {
            if (input == "/quit") {
                break;
            } else if (input.rfind("/image ", 0) == 0) {
                std::string path = input.substr(7);
                sendMediaFile(path, PacketType::MSG_IMAGE);
            } else if (input.rfind("/video ", 0) == 0) {
                std::string path = input.substr(7);
                sendMediaFile(path, PacketType::MSG_VIDEO_CHUNK);
            } else if (input.rfind("/audio ", 0) == 0) {
                std::string path = input.substr(7);
                sendMediaFile(path, PacketType::MSG_AUDIO_VOICE);
            } else if (!input.empty()) {
                sendTextMessage(input);
            }
        }

        disconnect();
    }

    void disconnect() {
        if (!is_running) return;
        is_running = false;
        if (socket_fd >= 0) {
            close(socket_fd);
            socket_fd = -1;
        }
        if (rx_thread.joinable()) {
            rx_thread.join();
        }
        std::cout << "[DISCONNECTED] Chat client exited.\\n";
    }

private:
    void sendAuth() {
        auto now = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

        auto packet = PacketSerializer::createPacket(
            PacketType::AUTH_REQUEST,
            0,
            0,
            now,
            reinterpret_cast<const uint8_t*>(username.data()),
            username.size()
        );
        send(socket_fd, packet.data(), packet.size(), 0);
    }

    void receiveLoop() {
        while (is_running) {
            PacketHeader header{};
            ssize_t n = recv(socket_fd, &header, sizeof(PacketHeader), MSG_WAITALL);
            if (n <= 0) break;

            if (header.magic != MAGIC_HEADER) continue;

            std::vector<uint8_t> payload(header.payload_len);
            if (header.payload_len > 0) {
                ssize_t total = 0;
                while (total < static_cast<ssize_t>(header.payload_len)) {
                    ssize_t chunk = recv(socket_fd, payload.data() + total,
                                         header.payload_len - total, 0);
                    if (chunk <= 0) break;
                    total += chunk;
                }
            }

            auto type = static_cast<PacketType>(header.packet_type);
            if (type == PacketType::MSG_TEXT) {
                std::string text(reinterpret_cast<const char*>(payload.data()), payload.size());
                std::cout << "\\n[User #" << header.sender_id << "]: " << text << "\\n> " << std::flush;
            } else if (type == PacketType::MSG_IMAGE) {
                std::cout << "\\n[Media Received] Image (" << payload.size() << " bytes) from #" << header.sender_id << "\\n> " << std::flush;
            } else if (type == PacketType::MSG_VIDEO_CHUNK) {
                std::cout << "\\n[Media Received] Video (" << payload.size() << " bytes) from #" << header.sender_id << "\\n> " << std::flush;
            } else if (type == PacketType::MSG_AUDIO_VOICE) {
                std::cout << "\\n[Media Received] Voice Audio (" << payload.size() << " bytes) from #" << header.sender_id << "\\n> " << std::flush;
            }
        }
    }
};

int main(int argc, char* argv[]) {
    std::string name = "DevUser";
    if (argc > 1) name = argv[1];

    ChatClient client(name);
    if (!client.connectToServer("127.0.0.1", 8080)) {
        return 1;
    }
    client.runConsole();
    return 0;
}
`
  },
  {
    name: 'CMakeLists.txt',
    language: 'cmake',
    description: 'বিল্ড স্ক্রিপ্ট ও কম্পাইলেশন কনফিগারেশন (CMake Build Configuration)',
    content: `cmake_minimum_required(VERSION 3.20)
project(Chitthi_CPP VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# Optimization & Compiler warnings
if(MSVC)
    add_compile_options(/W4 /O2)
else()
    add_compile_options(-Wall -Wextra -Wpedantic -O3 -pthread)
endif()

# Threading Library
find_package(Threads REQUIRED)

# Executables
add_executable(chat_server server.cpp protocol.hpp)
target_link_libraries(chat_server PRIVATE Threads::Threads)

add_executable(chat_client client.cpp protocol.hpp)
target_link_libraries(chat_client PRIVATE Threads::Threads)
`
  },
  {
    name: 'Makefile',
    language: 'makefile',
    description: 'লিনাক্স/ম্যাকের জন্য কুইক মেকফাইল (Quick Linux/macOS Build Makefile)',
    content: `CXX = g++
CXXFLAGS = -std=c++20 -Wall -Wextra -O3 -pthread

all: chat_server chat_client

chat_server: server.cpp protocol.hpp
	$(CXX) $(CXXFLAGS) server.cpp -o chat_server

chat_client: client.cpp protocol.hpp
	$(CXX) $(CXXFLAGS) client.cpp -o chat_client

clean:
	rm -f chat_server chat_client
`
  },
  {
    name: 'README.md',
    language: 'markdown',
    description: 'প্রজেক্ট রান এবং কম্পাইল করার পূর্ণাঙ্গ গাইড (Bengali & English Guide)',
    content: `# Chitthi: C++ Multimedia Real-Time Chat Engine

একটি সম্পূর্ণ আধুনিক **C++20** মাল্টি-ইউজার মাল্টিমিডিয়া চ্যাট অ্যাপ্লিকেশন।
এখানে একাধিক ব্যবহারকারী একসঙ্গে টেক্সট চ্যাট, ছবি (Images), ভিডিও (Videos) এবং অডিও ভয়েস মেসেজ আদান-প্রদান করতে পারে।

## প্রজেক্ট আর্কিটেকচার (How it works):
1. **TCP Sockets (POSIX/BSD)**: নির্ভরযোগ্য ডেটা ট্রান্সফারের জন্য ব্যবহৃত হয়েছে।
2. **Binary Framing Protocol (protocol.hpp)**: ফিক্সড হেডার ও ডাইনামিক পেলোড ফ্রেম স্ট্রাকচার। প্রতিটি মেসেজের জন্য ম্যাজিক নাম্বার (0x50434854), প্যাকেট টাইপ, এবং সাইজ ভ্যালিডেশন রয়েছে।
3. **Multi-Threading**: প্রতিটি সংযুক্ত ক্লায়েন্টের জন্য স্বাধীন রিডার থ্রেড এবং ব্যাকগ্রাউন্ড রিসিভার হ্যান্ডলার।
4. **Multimedia Handling**: 
   - **Text**: UTF-8 স্ট্রিং পেলোড।
   - **Image**: PNG/JPEG বাইনারি বাফার ড্রিলিং।
   - **Video**: চ্যাঙ্কড বাইটস্ট্রিম প্যাকেট।
   - **Voice/Audio**: রিয়েলটাইম PCM / WebM অডিও ফ্রেম।

---

## কম্পাইল ও রান করার নিয়ম (Compilation Guide):

### লিনাক্স / উবুন্টু / ম্যাক (Linux & macOS):
\`\`\`bash
# 1. কোড কম্পাইল করুন:
g++ -std=c++20 server.cpp -lpthread -o chat_server
g++ -std=c++20 client.cpp -lpthread -o chat_client

# 2. সার্ভার চালু করুন (Port 8080):
./chat_server 8080

# 3. ক্লায়েন্ট চালু করুন (অন্য একটি টার্মিনালে):
./chat_client "Tanvir"
\`\`\`

### CMake দিয়ে বিল্ড:
\`\`\`bash
mkdir build && cd build
cmake ..
cmake --build .
./chat_server
\`\`\`

### উইন্ডোজ (Windows - MSVC / MinGW):
\`\`\`cmd
g++ -std=c++20 server.cpp -lws2_32 -o chat_server.exe
g++ -std=c++20 client.cpp -lws2_32 -o chat_client.exe
chat_server.exe
\`\`\`
`
  }
];
